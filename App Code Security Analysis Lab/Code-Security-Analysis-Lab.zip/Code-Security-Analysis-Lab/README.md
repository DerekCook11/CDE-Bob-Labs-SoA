# Security Analysis & Code Fixes Lab

Use IBM Bob to inspect, plan, remediate, and verify an intentionally vulnerable
task-management application. The frontend is plain HTML/CSS/JavaScript, the API
uses Flask, and data is stored in SQLite. PostgreSQL, Docker, Node.js, and root
access are not required to run the application.

> **Training warning:** This repository intentionally contains fake hardcoded
> secrets, SQL injection, XSS, unsafe error handling, and insecure runtime
> settings. Run it only on a private lab system. Never deploy it to production.

## Lab outcome

You will keep two versions side by side:

- `vulnerable-app/` — the untouched before version.
- `secure-app/` — the working copy Bob will remediate.

At the end, automated tests and a file comparison will demonstrate what changed
and whether normal functionality was preserved.

## Requirements

- Red Hat Enterprise Linux 9 or another system with Python 3.9+
- `python3-pip` and Python virtual-environment support
- IBM Bob with access to the extracted project
- Two terminal sessions
- A private lab VM or SSH port forwarding

If Python tooling is not already available, an administrator runs this once:

```bash
sudo dnf install -y python3 python3-pip
```

All remaining commands run as the normal lab user. Do not run the application
as root.

## Project structure

```text
Code-Security-Analysis-Lab/
├── vulnerable-app/          Original vulnerable baseline
│   ├── backend/             Flask and SQLite API
│   └── frontend/            Browser interface
├── secure-app/              Identical starting copy for Bob to fix
├── prompts/                 Prepared Bob prompts
├── reports/                 Bob's before/after reports
├── scripts/                 Start, compare, and reset helpers
├── tests/                   Functional and security regression tests
└── security_verification.py Static before/after checks
```

## Start the vulnerable application

From the project root, make the helper scripts executable:

```bash
chmod +x scripts/*.sh
```

In terminal 1, start the backend:

```bash
./scripts/start-backend.sh vulnerable-app
```

Expected output includes:

```text
Running on http://127.0.0.1:5000
```

In terminal 2, start the frontend:

```bash
./scripts/start-frontend.sh vulnerable-app
```

Open `http://VM-IP:8080` from a browser that can reach the VM. The frontend
automatically calls the same VM on port 5000.

For safer access without opening firewall ports, create an SSH tunnel from your
computer and then open `http://localhost:8080`:

```bash
ssh -L 5000:localhost:5000 -L 8080:localhost:8080 itzuser@VM-IP
```

## Confirm the baseline

Run the functional tests. They should pass:

```bash
source .venv/bin/activate
LAB_TARGET=vulnerable-app python3 -m unittest tests.test_api
```

Run the security regression tests. They are intentionally expected to fail:

```bash
LAB_TARGET=vulnerable-app python3 -m unittest tests.test_security_regression
```

Run the six static security checks. The vulnerable version should report six
failures:

```bash
python3 security_verification.py vulnerable-app
```

## Drive the lab with Bob

Open [`prompts/bob-prompts.md`](prompts/bob-prompts.md) and run the prompts in
this order:

1. Ask Mode — understand the application.
2. Plan Mode — find and prioritize vulnerabilities.
3. Agent Mode — fix only `secure-app/`.
4. Verification — rescan, test, and compare.

The original `vulnerable-app/` must remain unchanged throughout the exercise.

## Verify Bob's changes

After Agent Mode finishes, normal functions must still pass:

```bash
LAB_TARGET=secure-app python3 -m unittest tests.test_api
```

The security regression suite and six static checks should now pass:

```bash
LAB_TARGET=secure-app python3 -m unittest tests.test_security_regression
python3 security_verification.py secure-app
```

Display every code difference between the before and after versions:

```bash
./scripts/compare-versions.sh
```

To run the secured application, stop the current servers and use:

```bash
cp secure-app/backend/.env.example secure-app/backend/.env
# Replace the placeholders in secure-app/backend/.env with lab-only values.
./scripts/start-backend.sh secure-app
./scripts/start-frontend.sh secure-app
```

## Restore the exercise

If you want to repeat the lab, reset the secure working copy:

```bash
./scripts/reset-secure-app.sh
```

The script preserves the previous secure version in a timestamped backup before
creating a fresh copy. The vulnerable baseline is never modified.

## Intended findings

Bob should identify at least these categories:

| Finding | Vulnerable location | Expected remediation |
|---|---|---|
| Hardcoded secrets | `backend/config.py` | Environment variables and safe startup behavior |
| SQL injection | `search_tasks()` | Parameterized query |
| Stored XSS | `frontend/app.js` | Safe DOM construction and `textContent` |
| Missing validation | Create and update routes | Type, presence, and length validation |
| Sensitive error disclosure | Global error handler | Server logging and generic client response |
| Insecure configuration | Debug mode and wildcard CORS | Secure defaults and allowed-origin configuration |
| Secret exposure | Administrative endpoints | Remove sensitive output and enforce access controls |

## Success criteria

- The vulnerable application starts without an external database.
- Functional tests pass before and after remediation.
- Bob identifies the intended findings with evidence and severity.
- Bob modifies only `secure-app/`.
- Security tests fail before remediation and pass afterward.
- The final report maps every original finding to its remediation and evidence.
