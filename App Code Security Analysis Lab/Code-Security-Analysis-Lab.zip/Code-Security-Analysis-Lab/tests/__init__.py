"""Lab verification tests."""

