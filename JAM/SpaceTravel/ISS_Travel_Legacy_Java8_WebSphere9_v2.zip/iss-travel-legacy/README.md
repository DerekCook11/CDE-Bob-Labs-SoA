# ISS Travel App — Legacy WebSphere / Java 8

This project is intentionally designed as a **legacy Java application** for an IBM Bob Java modernization lab.

## Scenario

**ISS Travel App** is an internal travel-planning application used by International Space Station program staff to review mission-related travel requests, destinations, and approval status.

The browser UI is plain `index.html + main.js`. The backend is a Java EE 7 WAR intended for **IBM WebSphere Application Server 9** and **Java 8**.

The application deliberately contains modernization targets:

- Java 8 source/target
- Java EE 7 / `javax.*`
- WebSphere-specific APIs
- `was_public.jar` dependency
- IBM-specific deployment descriptors
- EAR packaging
- old-style `web.xml`
- server-name and security checks tied to WebSphere
- no cloud-native health endpoint standard
- no Open Liberty configuration

The goal is to give the entire project to **IBM Bob** and ask it to modernize the application to Java 17 + Open Liberty while preserving behavior.


## Application behavior

The legacy portal now supports both viewing and adding travel requests:

- `GET /api/trips` — list all requests
- `GET /api/trips?id=1001` — retrieve one request
- `POST /api/trips` — add a request
- `GET /api/health` — legacy health endpoint

New requests are stored **in memory only**. Restarting the application restores the original sample data. This is intentional for the modernization lab so the exercise stays focused on Java/WebSphere modernization rather than database migration.

## Legacy architecture

```text
Browser
  |
  | index.html + main.js
  v
IBM WebSphere Application Server 9
  |
  +-- ISS Travel WAR
  |     +-- TravelServlet
  |     +-- HealthServlet
  |     +-- SecurityUtil
  |     +-- ServerInfoUtil
  |
  +-- WebSphere-specific APIs
  |     +-- WSSecurityHelper
  |     +-- ServerName
  |     +-- ResponseUtils
  |     +-- WsnInitialContextFactory
  |
  +-- IBM deployment descriptors
        +-- ibm-web-bnd.xml
        +-- ibm-web-ext.xml
        +-- ibm-metadata.xml
```

## Project structure

```text
iss-travel-legacy/
├── pom.xml
├── README.md
├── MODERNIZATION-TASK.md
├── legacy-web/
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/ibm/demo/isstravel/...
│       └── webapp/
│           ├── index.html
│           ├── main.js
│           └── WEB-INF/
│               ├── web.xml
│               ├── ibm-web-bnd.xml
│               ├── ibm-web-ext.xml
│               └── ibm-metadata.xml
└── legacy-ear/
    ├── pom.xml
    └── src/main/application/META-INF/application.xml
```

## Build expectations

The legacy project expects a WebSphere installation that provides `was_public.jar`.

By default the Maven build looks for:

```text
${WAS_HOME}/plugins/com.ibm.ws.runtime.jar
```

or a manually supplied `lib/was_public.jar` if you adapt the POM.

This dependency is intentional: Bob should identify it as a WebSphere coupling that must be removed during modernization.

## Suggested modernization target

- Open Liberty
- Java 17
- WAR-only deployment
- Java EE 8 / standard Servlet 4.0 APIs
- Remove WebSphere-specific API usage
- Remove IBM-specific descriptors
- Add `server.xml`
- Add Maven Liberty plugin
- Preserve browser UI and REST behavior

See `MODERNIZATION-TASK.md`.
