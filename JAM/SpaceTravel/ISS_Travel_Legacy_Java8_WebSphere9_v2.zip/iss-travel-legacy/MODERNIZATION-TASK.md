# IBM Bob Modernization Task

Modernize the **ISS Travel App** from IBM WebSphere Application Server 9 / Java 8 to **Open Liberty / Java 17**.

## Preserve

- `index.html`
- `main.js`
- `GET /api/trips`
- `POST /api/trips`
- `GET /api/trips?id=<id>`
- `GET /api/health`
- JSON response shapes
- ability to create a new travel request from the browser UI
- existing sample travel data

## Modernize

1. Upgrade Java from 8 to 17.
2. Replace WebSphere-specific APIs with portable Java / Servlet APIs.
3. Remove the `was_public.jar` dependency.
4. Remove EAR packaging unless it is still technically required.
5. Remove IBM-specific deployment descriptors:
   - `ibm-web-bnd.xml`
   - `ibm-web-ext.xml`
   - `ibm-metadata.xml`
6. Update the web application to Servlet 4.0 / Java EE 8.
7. Create Open Liberty `server.xml`.
8. Add the Liberty Maven plugin.
9. Keep the UI unchanged.
10. Build and test the modernized application.
11. Produce a modernization report containing:
    - files changed
    - before/after architecture
    - dependencies removed
    - Java version changes
    - deployment changes
    - verification results

## Acceptance criteria

- `mvn clean package` succeeds on Java 17.
- Application runs on Open Liberty.
- `/api/health` returns HTTP 200.
- `GET /api/trips` returns the same travel records as the legacy version.
- `POST /api/trips` creates a new in-memory travel request and returns HTTP 201.
- The browser UI can add a request and immediately show it in the table.
- No source file imports `com.ibm.websphere.*` or `com.ibm.ws.*`.
- No `was_public.jar` dependency remains.
- No IBM-specific deployment descriptor remains.
