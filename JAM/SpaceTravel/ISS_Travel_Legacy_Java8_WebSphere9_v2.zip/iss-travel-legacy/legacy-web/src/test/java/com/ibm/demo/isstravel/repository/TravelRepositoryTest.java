package com.ibm.demo.isstravel.repository;

import org.junit.Assert;
import org.junit.Test;

public class TravelRepositoryTest {

    @Test
    public void shouldContainSampleTravelRequests() {
        Assert.assertTrue(TravelRepository.findAll().size() >= 4);
        Assert.assertNotNull(TravelRepository.findById(1001));
    }
}
