package com.ibm.demo.isstravel.legacy;

import com.ibm.websphere.runtime.ServerName;

/**
 * INTENTIONAL LEGACY CODE.
 * Uses WebSphere runtime details directly.
 */
public final class WebSphereServerInfo {

    private WebSphereServerInfo() {}

    public static String serverName() {
        try {
            return ServerName.getFullName();
        } catch (Throwable t) {
            return "WebSphere-unknown";
        }
    }
}
