package com.ibm.demo.isstravel.web;

import com.ibm.demo.isstravel.legacy.WebSphereSecurityUtil;
import com.ibm.demo.isstravel.model.TravelRequest;
import com.ibm.demo.isstravel.repository.TravelRepository;
import com.ibm.demo.isstravel.util.JsonUtil;
import com.ibm.ws.webcontainer.util.ResponseUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;

/**
 * INTENTIONAL LEGACY CODE:
 * - javax.servlet
 * - WebSphere ResponseUtils
 * - WebSphere security helper
 */
@WebServlet(urlPatterns = "/api/trips")
public class TravelServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        ResponseUtils.setContentType(resp, "application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("X-Legacy-User", WebSphereSecurityUtil.currentUser());

        String idParam = req.getParameter("id");
        if (idParam == null || idParam.trim().isEmpty()) {
            resp.getWriter().write(JsonUtil.toJson(TravelRepository.findAll()));
            return;
        }

        try {
            int id = Integer.parseInt(idParam);
            TravelRequest request = TravelRepository.findById(id);
            if (request == null) {
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                resp.getWriter().write("{\"error\":\"Travel request not found\"}");
                return;
            }
            resp.getWriter().write(JsonUtil.toJson(request));
        } catch (NumberFormatException ex) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\":\"Invalid id\"}");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        ResponseUtils.setContentType(resp, "application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("X-Legacy-User", WebSphereSecurityUtil.currentUser());

        StringBuilder body = new StringBuilder();
        BufferedReader reader = req.getReader();
        String line;
        while ((line = reader.readLine()) != null) {
            body.append(line);
        }

        String json = body.toString();
        String traveler = JsonUtil.readString(json, "traveler");
        String destination = JsonUtil.readString(json, "destination");
        String purpose = JsonUtil.readString(json, "purpose");
        String departureDate = JsonUtil.readString(json, "departureDate");
        String status = JsonUtil.readString(json, "status");

        if (isBlank(traveler) || isBlank(destination) ||
            isBlank(purpose) || isBlank(departureDate)) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write(
                "{\"error\":\"traveler, destination, purpose and departureDate are required\"}"
            );
            return;
        }

        TravelRequest created = TravelRepository.add(
            traveler, destination, purpose, departureDate, status
        );

        resp.setStatus(HttpServletResponse.SC_CREATED);
        resp.getWriter().write(JsonUtil.toJson(created));
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
