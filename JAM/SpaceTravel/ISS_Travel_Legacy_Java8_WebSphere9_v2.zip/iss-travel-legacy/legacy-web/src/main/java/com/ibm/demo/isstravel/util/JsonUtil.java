package com.ibm.demo.isstravel.util;

import com.ibm.demo.isstravel.model.TravelRequest;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class JsonUtil {

    private JsonUtil() {}

    public static String toJson(TravelRequest r) {
        return "{"
            + "\"id\":" + r.getId() + ","
            + "\"traveler\":\"" + escape(r.getTraveler()) + "\","
            + "\"destination\":\"" + escape(r.getDestination()) + "\","
            + "\"purpose\":\"" + escape(r.getPurpose()) + "\","
            + "\"departureDate\":\"" + escape(r.getDepartureDate()) + "\","
            + "\"status\":\"" + escape(r.getStatus()) + "\""
            + "}";
    }

    public static String toJson(List<TravelRequest> requests) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < requests.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(toJson(requests.get(i)));
        }
        return sb.append("]").toString();
    }

    // Intentionally lightweight legacy parsing to keep the lab dependency-free.
    public static String readString(String json, String key) {
        Pattern pattern = Pattern.compile(
            "\"" + Pattern.quote(key) + "\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\""
        );
        Matcher matcher = pattern.matcher(json);
        if (!matcher.find()) {
            return null;
        }
        return unescape(matcher.group(1));
    }

    private static String escape(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r");
    }

    private static String unescape(String value) {
        return value.replace("\\n", "\n")
                    .replace("\\r", "\r")
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\");
    }
}
