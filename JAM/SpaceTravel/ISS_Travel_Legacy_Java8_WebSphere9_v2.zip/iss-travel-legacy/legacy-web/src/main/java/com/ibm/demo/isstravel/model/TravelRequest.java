package com.ibm.demo.isstravel.model;

public class TravelRequest {
    private final int id;
    private final String traveler;
    private final String destination;
    private final String purpose;
    private final String departureDate;
    private final String status;

    public TravelRequest(int id, String traveler, String destination,
                         String purpose, String departureDate, String status) {
        this.id = id;
        this.traveler = traveler;
        this.destination = destination;
        this.purpose = purpose;
        this.departureDate = departureDate;
        this.status = status;
    }

    public int getId() { return id; }
    public String getTraveler() { return traveler; }
    public String getDestination() { return destination; }
    public String getPurpose() { return purpose; }
    public String getDepartureDate() { return departureDate; }
    public String getStatus() { return status; }
}
