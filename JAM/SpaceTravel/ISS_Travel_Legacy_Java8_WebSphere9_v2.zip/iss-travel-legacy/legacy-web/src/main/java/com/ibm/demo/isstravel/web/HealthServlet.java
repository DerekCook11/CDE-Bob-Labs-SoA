package com.ibm.demo.isstravel.web;

import com.ibm.demo.isstravel.legacy.WebSphereServerInfo;
import com.ibm.ws.webcontainer.util.ResponseUtils;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Legacy, vendor-coupled health endpoint.
 */
@WebServlet(urlPatterns = "/api/health")
public class HealthServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        ResponseUtils.setContentType(resp, "application/json");
        resp.getWriter().write(
            "{\"status\":\"UP\",\"runtime\":\"IBM WebSphere 9\",\"server\":\""
            + WebSphereServerInfo.serverName()
            + "\",\"java\":\""
            + System.getProperty("java.version")
            + "\"}"
        );
    }
}
