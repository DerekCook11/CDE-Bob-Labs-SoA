package com.ibm.demo.isstravel.legacy;

import com.ibm.websphere.naming.WsnInitialContextFactory;

import javax.naming.Context;
import javax.naming.NamingException;
import java.util.Hashtable;

/**
 * INTENTIONAL LEGACY CODE.
 * Demonstrates direct use of the WebSphere naming factory.
 */
public final class LegacyNamingFactory {

    private LegacyNamingFactory() {}

    public static Context createContext() throws NamingException {
        Hashtable<String, String> env = new Hashtable<String, String>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, WsnInitialContextFactory.class.getName());
        return new WsnInitialContextFactory().getInitialContext(env);
    }
}
