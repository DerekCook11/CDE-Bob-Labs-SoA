package com.ibm.demo.isstravel.legacy;

import com.ibm.websphere.security.WSSecurityHelper;

/**
 * INTENTIONAL LEGACY CODE.
 * This class couples the application to IBM WebSphere security APIs.
 */
public final class WebSphereSecurityUtil {

    private WebSphereSecurityUtil() {}

    public static String currentUser() {
        try {
            String user = WSSecurityHelper.getCallerSubject() == null
                    ? null
                    : WSSecurityHelper.getCallerSubject().toString();
            return user == null ? "anonymous" : user;
        } catch (Exception ex) {
            return "unknown";
        }
    }
}
