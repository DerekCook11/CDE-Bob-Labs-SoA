package com.ibm.demo.isstravel.repository;

import com.ibm.demo.isstravel.model.TravelRequest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public final class TravelRepository {

    private static final List<TravelRequest> REQUESTS =
        Collections.synchronizedList(new ArrayList<TravelRequest>(Arrays.asList(
            new TravelRequest(1001, "Elena Torres", "Houston, TX",
                    "Mission operations readiness review", "2026-10-03", "APPROVED"),
            new TravelRequest(1002, "Marcus Lee", "Cape Canaveral, FL",
                    "Crew launch support", "2026-10-11", "PENDING"),
            new TravelRequest(1003, "Aisha Rahman", "Cologne, Germany",
                    "ESA payload integration workshop", "2026-11-02", "APPROVED"),
            new TravelRequest(1004, "Daniel Novak", "Tsukuba, Japan",
                    "JAXA systems coordination", "2026-11-14", "REVIEW")
        )));

    private static final AtomicInteger NEXT_ID = new AtomicInteger(1005);

    private TravelRepository() {}

    public static List<TravelRequest> findAll() {
        synchronized (REQUESTS) {
            return new ArrayList<TravelRequest>(REQUESTS);
        }
    }

    public static TravelRequest findById(int id) {
        synchronized (REQUESTS) {
            for (TravelRequest request : REQUESTS) {
                if (request.getId() == id) {
                    return request;
                }
            }
        }
        return null;
    }

    public static TravelRequest add(String traveler, String destination,
                                    String purpose, String departureDate,
                                    String status) {
        TravelRequest request = new TravelRequest(
                NEXT_ID.getAndIncrement(),
                traveler,
                destination,
                purpose,
                departureDate,
                status == null || status.trim().isEmpty()
                        ? "PENDING"
                        : status.trim().toUpperCase()
        );
        REQUESTS.add(request);
        return request;
    }
}
