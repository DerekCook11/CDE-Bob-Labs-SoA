async function loadTrips() {
  const error = document.getElementById("error");
  const rows = document.getElementById("rows");
  if (error) error.textContent = "";
  rows.innerHTML = "";

  try {
    const response = await fetch("api/trips");
    if (!response.ok) throw new Error("HTTP " + response.status);
    const trips = await response.json();

    for (const trip of trips) {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${escapeHtml(trip.id)}</td>
        <td>${escapeHtml(trip.traveler)}</td>
        <td>${escapeHtml(trip.destination)}</td>
        <td>${escapeHtml(trip.purpose)}</td>
        <td>${escapeHtml(trip.departureDate)}</td>
        <td class="${escapeHtml(trip.status)}">${escapeHtml(trip.status)}</td>`;
      rows.appendChild(tr);
    }
  } catch (e) {
    if (error) error.textContent = "Unable to load travel requests: " + e.message;
  }
}

async function addTravelRequest(event) {
  event.preventDefault();

  const error = document.getElementById("error");
  const success = document.getElementById("success");
  error.textContent = "";
  success.textContent = "";

  const payload = {
    traveler: document.getElementById("traveler").value.trim(),
    destination: document.getElementById("destination").value.trim(),
    purpose: document.getElementById("purpose").value.trim(),
    departureDate: document.getElementById("departureDate").value,
    status: document.getElementById("status").value
  };

  try {
    const response = await fetch("api/trips", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload)
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || ("HTTP " + response.status));
    }

    success.textContent = "Travel request " + data.id + " added successfully.";
    document.getElementById("travelForm").reset();
    await loadTrips();
  } catch (e) {
    error.textContent = "Unable to add travel request: " + e.message;
  }
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

window.addEventListener("DOMContentLoaded", function () {
  document.getElementById("travelForm").addEventListener("submit", addTravelRequest);
  loadTrips();
});
