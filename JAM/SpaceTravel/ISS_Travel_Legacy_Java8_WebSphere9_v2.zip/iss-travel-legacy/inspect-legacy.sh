#!/usr/bin/env bash
set -e
echo "=== Java version target ==="
grep -R "<maven.compiler.source>\|<source>1.8\|<target>1.8" -n pom.xml legacy-web/pom.xml || true
echo
echo "=== WebSphere-specific imports ==="
grep -R "import com.ibm.websphere\|import com.ibm.ws" -n legacy-web/src/main/java || true
echo
echo "=== IBM deployment descriptors ==="
find legacy-web/src/main/webapp/WEB-INF -maxdepth 1 -type f -name 'ibm-*' -print
echo
echo "=== EAR module ==="
find legacy-ear -type f -maxdepth 6 -print
